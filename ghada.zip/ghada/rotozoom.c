#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_rotozoom.h>
 
#define TEMPS       25
 
int loading()
{
    SDL_Surface *fond=NULL ,*image = NULL, *rotation = NULL;
    SDL_Rect rect,pos;
    SDL_Event event;
    double angle = 0;
    double zoom = 1.0;
    int sens =1 ;


    pos.x=0;
    pos.y=0;


 
    int continuer = 1;
    int tempsPrecedent = 0, tempsActuel = 0;
 

 
    image = IMG_Load("diamond.png");// l'image a tourner
    fond = IMG_Load ("bg.jpg");// l'image de background


 
    while(continuer)
    {
        SDL_PollEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
        }
 
        tempsActuel = SDL_GetTicks();
        if (tempsActuel - tempsPrecedent > TEMPS)
        {
            angle += 2; 
            
            

            tempsPrecedent = tempsActuel;
        }
        else
        {
            SDL_Delay(TEMPS - (tempsActuel - tempsPrecedent));
        }
 
         SDL_BlitSurface(fond,NULL,ecran,&pos);
        rotation = rotozoomSurface(image, angle, zoom, 0); 


        rect.x =  640 - rotation->w / 2;
        rect.y =  287 - rotation->h / 2;


    
 
        SDL_BlitSurface(rotation , NULL, ecran, &rect); 
       
        SDL_FreeSurface(rotation); 
    
 
        
        if(zoom >= 2){sens = 0;}
        else if(zoom <= 0.5){sens = 1;}
 
        if(sens == 0){zoom -= 0.02;}
        else{zoom += 0.02;}


        SDL_Flip(ecran);
    }
 
    SDL_FreeSurface(ecran);
    SDL_FreeSurface(image);
    SDL_Quit();
 
    return EXIT_SUCCESS;
}
