
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_rotozoom.h>
 

void jump(SDL_Event event, Hero *hero)
{
    if(hero->frame != 9)
    {
        if(hero->air && hero->e.position.y > JumpLimit && !hero->sol)
            hero->e.position.y += Gravity;
        if(hero->e.position.y <= JumpLimit )
            hero->sol = 1;
        if(hero->e.position.y < Hero_Default_Y && hero->sol )
            hero->e.position.y -= Gravity;
        if(hero->e.position.y == Hero_Default_Y)
        {
            hero->sol = 0;
            hero->air = 0;
        }
    }
}